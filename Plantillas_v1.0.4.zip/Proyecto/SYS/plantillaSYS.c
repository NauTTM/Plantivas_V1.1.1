#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include<stdbool.h>
#include "../AD/plantillaAD.h"
#include "plantillaSYS.h"

bool altaJugadorPlantillaSys(int id_equipo, char id_jugador[])//Funcion que llama a alatajugadorplantillaAD para saber si se ha abierto y escrito correctamente la nueva plantilla
{
    if(altaJugadorPlantillaAD(id_equipo,id_jugador) == -1)//Si devuelve esto no se ha podido abrir el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("La plantilla %d se ha registrado correctamente", id_equipo);
        return true ;
    }
}
