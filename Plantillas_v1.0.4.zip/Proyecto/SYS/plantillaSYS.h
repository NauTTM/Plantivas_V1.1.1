#include<stdbool.h>
bool altaJugadorPlantillaSys(int id_equipo, char id_jugador[]);
