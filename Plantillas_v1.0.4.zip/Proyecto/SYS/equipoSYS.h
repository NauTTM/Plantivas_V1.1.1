#include<stdbool.h>
#define DIM_NOMBRE_EQUIPO 50
bool altaEquipoSYS(int id_equipo, char nombre[]);
int cargaListaEquiposSYS(int id_equipo[], char nombre[][DIM_NOMBRE_EQUIPO]);
bool guardaListaEquiposSYS(int numEquipos, int id_equipo[],char nombre_equipo[][DIM_NOMBRE_EQUIPO]);
