#define NUM_EQUIPOS 100
#define DIM_NOMBRE_EQUIPO 50
int altaEquipoAD(int IdEquipo, char Nombre[]);
int cargaListaEquiposAD(int id_equipo[], char nombre_equipo[][DIM_NOMBRE_EQUIPO]);
int guardaListaEquiposAD(int numEquipos, int id_equipo[],char nombre[][DIM_NOMBRE_EQUIPO ]);
