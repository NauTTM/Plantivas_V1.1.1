#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "plantillaAD.h"

int altaJugadorPlantillaAD(int id_equipo, char id_jugador[])//Funcion que abre el archivo y escribe la nueva plantilla en el para registrarla
{
    FILE *ptr;
    ptr=fopen("BaseDatos/plantillas.txt","at");//Se abre en modo a�adir texto
    fprintf(ptr,"%d %s\n",id_equipo,id_jugador);
    fclose(ptr);
    return 0;
}
