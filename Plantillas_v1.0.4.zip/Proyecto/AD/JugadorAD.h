#define DIM_NOMBRE_JUGADOR 50
int altaJugadorAD(char id_jugador[], char pais[], char fnac[], float altura, char nombre[]);
int cargaListaJugadoresAD(char id_jugador[][10], char pais[][4],char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR]);
int guardaListaJugadoresAD(int numJugadores, char id_jugador[][10],char pais[][4], char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR]);
