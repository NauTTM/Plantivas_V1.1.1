int altaJugadorPlantillaAD(int id_equipo, char id_jugador[]);
