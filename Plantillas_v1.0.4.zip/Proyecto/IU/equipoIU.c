#include<stdio.h>
#include<conio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "../AD/equipoAD.h"
#include "../SYS/equipoSYS.h"
#include "equipoIU.h"
#define NUM_EQUIPOS 100
#define DIM_NOMBRE_EQUIPO 50

void gestionMenuEquipos()//Funcion para crear el menu de las opciones spbre los equipos
{
    int opcion_usuario;

    opcion_usuario = menuEquipos();

    while(opcion_usuario!=0)
    {
        switch(opcion_usuario)
        {
        case 1:
            listadoEquipos();
            break;
        case 2:
            altaEquipoIU();
            break;
        case 3:
            bajaEquipoIU();
            break;
        default:
            printf("Opci�n erronea.\n");
        }
        opcion_usuario = menuEquipos();
    }
    return;
}

int menuEquipos()//Funcion para saber que opciones tenemos en el menu equipos
{
    rellenaRectangulo(0, 10, 60, 32);
    int opcion;
    gotoxy(10, 8);
    printf("MENU DE OPCIONES");
    gotoxy(2, 11);
    printf( "1. Listado de equipos.\n");
    gotoxy(2, 12);
    printf( "2. Tramitar alta de un equipo\n");
    gotoxy(2, 13);
    printf( "3. Tramitar baja de un equipo\n");
    gotoxy(2, 14);
    printf( "0. Volver al menu anterior.\n");

    gotoxy(2, 17);
    printf("Selecciona una opcion: ");
    scanf("%d", &opcion);

   return opcion;
}

void altaEquipoIU()//Funcion para apuntar a un nuevo equipo pidiendo al usuario el ID del equipo y su nombre
{
    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    rellenaRectangulo(0, 10, 60, 32);
    gotoxy(40, 44);
    int IdEquipo;
    printf("Introduzca ID del equipo:");
    scanf("%d",&IdEquipo);
    gotoxy(2, 11);
    printf("ID: %d",IdEquipo);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    printf("Introduzca nombre del equipo:");
    fflush(stdin);
    char Nombre[30];
    gets(Nombre);
    gotoxy(2, 12);
    printf("Nombre:%s", Nombre);
    rellenaRectangulo(24, 42, 80, 5);

    rellenaRectangulo(24, 42, 80, 5);
    gotoxy(40, 44);
    printf("Pulsa ENTER para continuar");
    getchar();


    rellenaRectangulo(65, 5, 90, 6);
    rellenaRectangulo(65, 10, 90, 6);
    rellenaRectangulo(65, 10, 90, 32);
    rectangulo(65, 5, 90, 3);
    rectangulo(65, 10, 90, 3);
    rectangulo(65, 15, 90, 25);
    gotoxy(100,7);
    printf("Nuevo equipo");
    gotoxy(66,13);
    printf("N");
    gotoxy(68,13);
    printf("ID");
    gotoxy(75,13);
    printf("Nombre");

    gotoxy(66,16);
    muestraEquipo(1, IdEquipo , Nombre);//Llamada a la funcion muestraequipo con los valores adquiridos
    altaEquipoSYS(IdEquipo,Nombre);//Llamada a la funcion altaequipoSYS con los valores adquiridos
}

void muestraEquipo(int orden, int id_equipo, char nombre[])//Funcion para mostrar los equipos de la lista o el equipo registrado
{
    printf("%d ", orden);
    printf("%d ", id_equipo);
    printf("%s ", nombre);
}

void listadoEquipos()//Funcion que llama a cargalistaequipos y a muestralistaequipos para que aparezcan en pantalla os equipos
{
    int id_equipo[NUM_EQUIPOS];
    char nombre_equipo[NUM_EQUIPOS][DIM_NOMBRE_EQUIPO];
    int contador = cargaListaEquiposSYS(id_equipo,nombre_equipo);
    if(contador == -1)//si devuleve esto no se ha podido abrir el archivo
        {
            printf("Error en la carga de las lista de los equipos");
        }
    else if(contador == 0)//Si devuelve esto no hay equipos en el archivo
        {
            printf("No hay equipos en el archivo equipos.txt");
        }
    else
        {
            muestraListaEquipos(contador,id_equipo,nombre_equipo);
        }

    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    gotoxy(40, 49);
    printf("Introduzca otra opcion para continuar");
    getchar();
    return;
}


void bajaEquipoIU()//Funcion para poder eliminar un equipo de nuestra base de datos
{
    int opcion, contador;           /*Se declaran las variables con sus vectores y la opcion del equipo que se quiere borrar
                                    se le da ese valor - 1 debido a que las cadenas empiezan a contar desde el 0*/
    int id_equipo[NUM_EQUIPOS];
    char nombre_equipo[NUM_EQUIPOS][DIM_NOMBRE_EQUIPO];
    contador = cargaListaEquiposSYS(id_equipo,nombre_equipo);
    muestraListaEquipos(contador,id_equipo,nombre_equipo);
    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    gotoxy(40, 44);
    printf("Elige un equipo por su numero de orden: ");
    scanf("%d",&opcion);
    id_equipo[opcion-1] = 0;
    guardaListaEquiposSYS(contador,id_equipo,nombre_equipo);
}
void muestraListaEquipos(int numEquipos, int id_equipo[],char nombre_equipo[][DIM_NOMBRE_EQUIPO])//Funcion que crea una grafica y lee el archivo jugadores.txt para cuando la llamen estos equipos se impriman por pantalla
{
    rellenaRectangulo(65, 5, 90, 6);
    rellenaRectangulo(65, 10, 90, 6);
    rellenaRectangulo(65, 10, 90, 32);
    rectangulo(65, 5, 90, 3);//Estos rectangulos se llaman en otras funciones y sirven para crear una una grafica al lado de la ya creada y donde aparece lo que pedimos a la consola
    rectangulo(65, 10, 90, 3);
    rectangulo(65, 15, 90, 25);
    gotoxy(100,7);
    printf("LISTADO DE EQUIPOS");
    gotoxy(66,13);
    printf("N");
    gotoxy(69,13);
    printf("ID");
    gotoxy(77,13);
    printf("Nombre");
    int i, pos = 1;
    int columna=66, fila=16;

    FILE*ptr;
    ptr=fopen("BaseDatos/equipos.txt","rt");//Se abre en modo lectura

    for(i=0;i<numEquipos;i++)//Bucle para leer el archivo equipos.txt e ir llamando a muestraEquipos sumando las filas y que aparezcan los equipos en filas diferentes
        {
            gotoxy(columna,fila);
            muestraEquipo(pos,id_equipo[i],nombre_equipo[i]);
            pos++;
            fila++;
        }
    fclose(ptr);
}

