#include <stdio.h>
#include "IU/interfazUsuario.h"
#include "IU/interfazGrafica.h"
#include "IU/equipoIU.h"
#include<conio.h>
#include "SYS/equipoSYS.h"
#include "AD/equipoAD.h"
/*Las llamadas a las funciones se hacen introduciendo en sus argumentos los valores de las variables con las que trabajamos
en la funcion para pasarlas de funcion en funcion y poder trabajar con variables locales  diferentes*/
int main()
{
    inicInterfazUsuario();//Llama a la funcion para crear la estructura del proyecto

    gestionMenuPrincipal();//Llamada a la funcion para que nos aparezca desde el inicio el menu principal con las diferentes opciones

    getch();
    return 0;
}
