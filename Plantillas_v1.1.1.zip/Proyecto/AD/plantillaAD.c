#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "plantillaAD.h"

int altaJugadorPlantillaAD(int id_equipo, char id_jugador[])//Funcion que abre el archivo y escribe la nueva plantilla en el para registrarla
{
    FILE *ptr;
    ptr=fopen("BaseDatos/plantillas.txt","at");//Se abre en modo a�adir texto
    fprintf(ptr,"%d %s\n",id_equipo,id_jugador);
    fclose(ptr);
    return 0;
}
int cargaListaJugadoresPlantillaAD(int id_equipo[],char id_jugador[][10])
{
    FILE *ptr;
    ptr=fopen("BaseDatos/plantillas.txt","rt");//Se abre en modo lectura
    int contador=0;
    while(fscanf(ptr,"%d %s",&id_equipo[contador],id_jugador[contador]) == 2)
    {
        contador++;
    }
    fclose(ptr);
    return contador;
}

int guardaListaJugadoresPlantillaAD(int numJugadores, int id_equipo[],char id_jugador[][10])
{
    FILE *ptr;
    ptr=fopen("BaseDatos/plantillas.txt","wt");//Se abre en modo escritura y se borra lo anterior
    int i,contador=0;
    for(i=0;i<numJugadores;i++)//con estos dos bucles hacemos que solo se escriban los jugadores que no hemos borrado
    {
        if(id_equipo[i]!=0)
        {
            fprintf(ptr,"%d %s\n",id_equipo[i], id_jugador[i]);
            contador++;
        }
    }
    fclose(ptr);
    return contador;
}
