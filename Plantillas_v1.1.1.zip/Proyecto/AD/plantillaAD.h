int altaJugadorPlantillaAD(int id_equipo, char id_jugador[]);
int cargaListaJugadoresPlantillaAD(int id_equipo[],char id_jugador[][10]);
int guardaListaJugadoresPlantillaAD(int numJugadores, int id_equipo[],char id_jugador[][10]);
