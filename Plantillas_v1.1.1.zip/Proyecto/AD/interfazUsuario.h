void inicInterfazUsuario();
