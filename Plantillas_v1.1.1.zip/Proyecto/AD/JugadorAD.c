#include <stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "JugadorAD.h"
#define DIM_NOMBRE_JUGADOR 50
#include <string.h>
int altaJugadorAD(char id_jugador[], char pais[], char fnac[], float altura, char nombre[])//Funcion que abre jugadores.txt en modo a�adir texto para inscribir al nuevo jugador
{
    FILE *ptr;
    ptr=fopen("BaseDatos/jugadores.txt","at");//se abre en modo a�adir texto
    fprintf(ptr,"%s %s %s %.2f %s\n",id_jugador,pais,fnac,altura,nombre);
    fclose(ptr);
    return 0;
}
int cargaListaJugadoresAD(char id_jugador[][10], char pais[][4],char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR])//Funcion que abre jugadores.txt en modo lectura para guardar a todos los jugadores inscritos
{
    FILE*ptr;
    ptr=fopen("BaseDatos/jugadores.txt","rt");//se abre en modo leer texto
    if(ptr==NULL)//si se devuelve esto ha habido un error al abir el programa
    {
        printf("Error en el archivo equipos.txt");
        getchar();
        return -1;
    }
    int contador=0;
    int x = 1;
    int pos = 1;
    while(fscanf(ptr,"%s %s %s %f",id_jugador[contador], pais[contador], fnac[contador], &altura[contador])==4)//con este bucle cargamos los jugadores en los diversos vectores definidos como i
    {
        fgets(nombre_jugador[contador],50,ptr);
        pos++;
        x++;
        contador++;
    }

    fclose(ptr);
    return contador;
}

int guardaListaJugadoresAD(int numJugadores, char id_jugador[][10],char pais[][4], char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR])//Funcion que abre el archivo jugadores.txt en modo escritura para escribir todos menos el que hemos querido borrar
{
    FILE *ptr;
    ptr=fopen("BaseDatos/jugadores.txt","wt");//se abre en modo escritura por lo que se borra todo lo escrito
    int contador=0;
    int i;
    char vacio[]="vacio";
    for(i=0;i<numJugadores;i++)
    {
        fflush(stdin);
        if(strcmp(vacio,id_jugador[i])!= 0)//se comparan la cadena vacio y la del DNI de los jugadores y solo si son diferentes se escriben los datos del jugador
        {
            fprintf(ptr,"%s %s %s %.2f%s",id_jugador[i],pais[i],fnac[i],altura[i],nombre_jugador[i]);
            contador++;
        }
    }
    fclose(ptr);
    return contador;
}
