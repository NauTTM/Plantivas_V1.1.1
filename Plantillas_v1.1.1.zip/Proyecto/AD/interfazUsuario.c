#include <stdio.h>
#include "interfazGrafica.h"
#include "interfazUsuario.h"
#include <conio.h>
void inicInterfazUsuario();

void inicInterfazUsuario()
{
    system("Proyecto");

    rectangulo(0, 0, 100, 3);
    rectangulo(0, 5, 60, 3);
    rectangulo(0, 10, 60, 30);
    rectangulo(0, 42, 20, 3);
    rectangulo(24, 42, 80, 3);
    rectangulo(0, 47, 20, 3);
    rectangulo(24, 47, 80, 3);

    gotoxy(40, 2);
    printf("GESTOR DE PLANTILLAS");
    gotoxy(20, 6);
    printf("Gestion de jugadores");
    gotoxy(2, 44);
    printf("ENTRADA DE DATOS");
    gotoxy(6, 49);
    printf("MENSAJES");
}
