#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "equipoAD.h"
#define NUM_EQUIPOS 100
#define DIM_NOMBRE_EQUIPO 50

int altaEquipoAD(int IdEquipo, char Nombre[], char Ciudad[])//Funcion que abre el archivo equipos.tx y a�ade en el a los nuevos jugadores
{
    FILE *ptr;
    ptr=fopen("BaseDatos/equipos.txt","at");//Se abre en modo a�adir texto
    fprintf(ptr,"%d %s %s\n",IdEquipo, Ciudad, Nombre);
    fclose(ptr);
    return 0;
}
int cargaListaEquiposAD(int id_equipo[], char nombre_equipo[][DIM_NOMBRE_EQUIPO],char Ciudad[][DIM_NOMBRE_EQUIPO])//Funcion que abre el archivo equipos.txt en modo lectura para cargar en ella los diversos equipos
{
    FILE *ptr;
    ptr=fopen("BaseDatos/equipos.txt","rt");//Se abre en modo lectura
    int contador=0;
    while(fscanf(ptr,"%d %s",&id_equipo[contador],Ciudad[contador]) == 2)
    {
        fgets(nombre_equipo[contador],50,ptr);
        contador++;
    }
    fclose(ptr);
    return contador;
}
int guardaListaEquiposAD(int numEquipos, int id_equipo[],char nombre[][DIM_NOMBRE_EQUIPO],char Ciudad[][DIM_NOMBRE_EQUIPO])//Funcion que abre el archivo equipos.txt en modo escritura para borrar todo y escribir todos los equipos menos el que queremos borrar
{
    FILE *ptr;
    ptr=fopen("BaseDatos/equipos.txt","wt");//Se abre en modo escritura y se borra lo anterior
    int i,contador=0;
    for(i=0;i<numEquipos;i++)//con estos dos bucles hacemos que solo se escriban los jugadores que no hemos borrado
    {
        if(id_equipo[i]!=0)
        {
            fprintf(ptr,"%d %s%s",id_equipo[i], Ciudad[i], nombre[i]);
            contador++;
        }
    }
    fclose(ptr);
    return contador;
}
