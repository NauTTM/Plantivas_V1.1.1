#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "PlantillasIU.h"
#include<conio.h>
#include "../AD/plantillaAD.h"
#include "../SYS/plantillaSYS.h"

void gestionMenuPlantillas()//funcion que crea el menu de las plantillas
{
    int opcion_usuario;

    opcion_usuario = menuPlantillas();

    while(opcion_usuario!=0)
    {
        switch(opcion_usuario)
        {
        case 1:
            listadoJugadoresPlantilla();
            break;
        case 2:
            altaJugadorPlantillaIU();
            break;
        case 3:
            bajaJugadorPlantillaIU();
            break;
        default:
            printf("Opci�n erronea.\n");
        }
        opcion_usuario = menuPlantillas();
    }
    return;
}

int menuPlantillas()//Funcion para saber que opciones hay en el menu
{
    rellenaRectangulo(0, 10, 60, 32);
    int opcion;
    gotoxy(10, 8);
    printf("MENU DE OPCIONES");
    gotoxy(2, 11);
    printf( "1. Listado de plantillas.\n");
    gotoxy(2, 12);
    printf( "2. Tramitar alta de una plantilla\n");
    gotoxy(2, 13);
    printf( "3. Tramitar baja de una plantillas\n");
    gotoxy(2, 14);
    printf( "0. Volver a menu anterior.\n");

    gotoxy(2, 17);
    printf("Selecciona una opcion: ");
    scanf("%d", &opcion);

   return opcion;
}

void altaJugadorPlantillaIU()//Funcion para dar de alta a una plantilla pidiendo el DNI del jugador y el identificador de equipo
{
    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    rellenaRectangulo(0, 10, 60, 32);
    gotoxy(40, 44);
    printf("Introduzca ID del jugador:");
    fflush(stdin);
    char IdJugador[10];
    gets(IdJugador);
    gotoxy(2, 13);
    printf("DNI:%s", IdJugador);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    int IdEquipo;
    printf("Introduzca ID del equipo :");
    scanf("%d",&IdEquipo);
    gotoxy(2, 14);
    printf("ID del equipo: %d",IdEquipo);
    rellenaRectangulo(24, 42, 80, 5);

    fflush(stdin);
    rellenaRectangulo(24, 42, 80, 5);
    gotoxy(40, 44);
    printf("Pulsa ENTER para continuar");
    getchar();

    rellenaRectangulo(65, 5, 90, 6);
    rellenaRectangulo(65, 10, 90, 6);
    rellenaRectangulo(65, 10, 90, 32);
    rectangulo(65, 5, 90, 3);
    rectangulo(65, 10, 90, 3);
    rectangulo(65, 15, 90, 25);
    gotoxy(100,7);
    printf("Listado jugador plantillas");
    gotoxy(66,13);
    printf("N");
    gotoxy(68,13);
    printf("ID");
    gotoxy(72,13);
    printf("DNI");

    gotoxy(66,16);
    muestraJugadorPlantilla(1, IdEquipo, IdJugador);//Llamadas para pasar los argumentos a otras funciones
    altaJugadorPlantillaSys(IdEquipo,IdJugador);
}

void muestraJugadorPlantilla(int pos, int id_equipo, char id_jugador[])
{
    printf("%d ",pos);
    printf("%d ",id_equipo);
    printf("%s",id_jugador);
}


void bajaJugadorPlantillaIU()//Funcion para dar de baja a un plantilla
{
    rellenaRectangulo(24, 47, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    gotoxy(40, 49);
    printf("En esta version no se encuentra disponible");
}

void listadoJugadoresPlantilla()//Funcion para mostrar la lista de plantillas
{
    int id_equipo[50];
    char id_jugador[50][10];
    int contador = cargaListaJugadoresPlantillaSYS(id_equipo,id_jugador);
    if(contador == -1)//si devuleve esto no se ha podido abrir el archivo
        {
            printf("Error en la carga de las lista de los equipos");
        }
    else if(contador == 0)//Si devuelve esto no hay plantillas en el archivo
        {
            printf("No hay equipos en el archivo equipos.txt");
        }
    else
        {
            muestraListaJugadoresPlantilla(contador,id_equipo,id_jugador);
        }

    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    gotoxy(40, 49);
    printf("Introduzca otra opcion para continuar");
    getchar();
    return;
}
void muestraListaJugadoresPlantilla (int numJugadores, int id_equipo[], char id_jugador[][10])
{
    rellenaRectangulo(65, 5, 90, 6);
    rellenaRectangulo(65, 10, 90, 6);
    rellenaRectangulo(65, 10, 90, 32);
    rectangulo(65, 5, 90, 3);//Estos rectangulos se llaman en otras funciones y sirven para crear una una grafica al lado de la ya creada y donde aparece lo que pedimos a la consola
    rectangulo(65, 10, 90, 3);
    rectangulo(65, 15, 90, 25);
    gotoxy(100,7);
    printf("LISTADO DE PLANTILLAS");
    gotoxy(66,13);
    printf("N");
    gotoxy(69,13);
    printf("ID");
    gotoxy(72,13);
    printf("DNI");

    int i;
    int pos = 1;
    int columna=66, fila=16;

    FILE*ptr;
    ptr=fopen("BaseDatos/plantillas.txt","rt");//Se abre en modo lectura

    for(i=0;i<numJugadores;i++)//Bucle para leer el archivo equipos.txt e ir llamando a muestraListaPlantillas sumando las filas y que aparezcan las plantillas en filas diferentes
        {
            gotoxy(columna,fila);
            muestraJugadorPlantilla(pos,id_equipo[i],id_jugador[i]);
            pos++;
            fila++;
        }
    fclose(ptr);
}
