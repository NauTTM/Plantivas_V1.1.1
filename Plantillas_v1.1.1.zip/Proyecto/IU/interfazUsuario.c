#include <stdio.h>
#include "interfazGrafica.h"
#include "interfazUsuario.h"
#include <conio.h>
#include "interfazUsuario.h"
#include "equipoIU.h"
#include "JugadorIU.h"
#include "PlantillasIU.h"

void inicInterfazUsuario()//Estructura del proyecto
{
    system("Proyecto");
    system("color F0");
    system("mode con cols=200 lines=52");//Tama�o de la consola

    rectangulo(0, 0, 100, 3);//Rectangulo de arriba del todo
    rectangulo(0, 5, 60, 3);//Rectangulo situado mas abajo
    rectangulo(0, 10, 60, 30);//Rectangulo donde esta el menu
    rectangulo(0, 42, 20, 3);//Rectangulo entradas
    rectangulo(24, 42, 80, 3);//Rectangulo hueco entradas
    rectangulo(0, 47, 20, 3);//Rectangulo mensajes
    rectangulo(24, 47, 80, 3);//Rectangulo con huecos para los mensajes

    gotoxy(40, 2);
    printf("GESTOR DE PLANTILLAS");
    gotoxy(2, 44);
    printf("ENTRADA DE DATOS");
    gotoxy(6, 49);
    printf("MENSAJES");
}

void gestionMenuPrincipal()//Funcion que crea el menu principal en el que aparecen las diferentes funciones
{
    int opcion_usuario;

    opcion_usuario = menuPrincipal();

    while(opcion_usuario!=0)
    {
        switch(opcion_usuario)
        {
        case 1:
            gestionMenuJugadores();
            break;
        case 2:
            gestionMenuEquipos();
            break;
        case 3:
            gestionMenuPlantillas();
            break;
        default:
            printf("Opci�n erronea.\n");
    }
    opcion_usuario = menuPrincipal();
    }
    return;
}

int menuPrincipal()//Funcion en la que se escriben en la consola a donde te dirige cada una de las opciones del menu principal
{
    rellenaRectangulo(0, 10, 60, 32);
    int opcion;
    gotoxy(10, 8);
    printf("MENU DE OPCIONES");
    gotoxy(2, 11);
    printf( "1. Gestion de jugadores.\n");
    gotoxy(2, 12);
    printf( "2. Gestion de equipos\n");
    gotoxy(2, 13);
    printf( "3. Gestion de plantillas\n");
    gotoxy(2, 14);
    printf( "0. Fin del Programa.\n");

    gotoxy(2, 17);
    printf("Selecciona una opcion: ");
    scanf("%d", &opcion);

   return opcion;
}
