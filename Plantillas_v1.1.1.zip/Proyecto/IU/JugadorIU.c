#include<stdio.h>
#include<conio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include "../AD/JugadorAD.h"
#include "../SYS/JugadorSYS.h"
#include "JugadorIU.h"
#define NUM_JUGADOR 60
#define DIM_NOMBRE_JUGADOR 50
#include <string.h>

void gestionMenuJugadores()//Funcion que crea el menu de la parte de los jugadores
{
    int opcion_usuario;

    opcion_usuario = menuJugadores();

    while(opcion_usuario!=0)
    {
        switch(opcion_usuario)
        {
        case 1:
            listadoJugadores();
            break;
        case 2:
            altaJugadorIU();;
            break;
        case 3:
            bajaJugadorIU();
            break;
        default:
            printf("Opci�n erronea.\n");
    }
    opcion_usuario = menuJugadores();
    }
    return;
}

int menuJugadores()//Funcion en la que escribe en pantalla las opciones del menu de los jugadores
{
    rellenaRectangulo(0, 10, 60, 32);
    int opcion;
    gotoxy(10, 8);
    printf("MENU DE OPCIONES");
    gotoxy(2, 11);
    printf( "1. Listado de jugadores.\n");
    gotoxy(2, 12);
    printf( "2. Tramitar alta de un jugador\n");
    gotoxy(2, 13);
    printf( "3. Tramitar baja de un jugador\n");
    gotoxy(2, 14);
    printf( "0. Volver al menu principal.\n");

    gotoxy(2, 17);
    printf("Selecciona una opcion: ");
    scanf("%d", &opcion);

   return opcion;
}

void altaJugadorIU()//Funcion para dar de alta a un nuevo jugadores pidiendo sus datos y luego lo muestra por pantalla
{
    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    rellenaRectangulo(0, 10, 60, 32);
    gotoxy(40, 44);
    printf("Introduzca ID del jugador:");
    fflush(stdin);
    char IdJugador[30];
    gets(IdJugador);
    gotoxy(2, 13);
    printf("DNI:%s", IdJugador);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    printf("Introduzca nacionalidad del jugador:");
    fflush(stdin);
    char Pais[4];
    gets(Pais);
    gotoxy(2, 14);
    printf("Nacionalidad:%s", Pais);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(36, 44);
    printf("Introduzca fecha de nacimiento del jugador dd/mm/aaaa:");
    fflush(stdin);
    char Fecha[11];
    gets(Fecha);
    gotoxy(2, 15);
    printf("Fecha de nacimiento:%s", Fecha);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    float NumAltura;
    printf("Introduzca altura del jugador :");
    scanf("%f",&NumAltura);
    gotoxy(2, 16);
    printf("Altura: %0.2f",NumAltura);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    printf("Introduzca nombre del jugador del jugador:");
    fflush(stdin);
    char Nombre[30];
    gets(Nombre);
    gotoxy(2, 17);
    printf("Nombre:%s", Nombre);
    rellenaRectangulo(24, 42, 80, 5);

    rellenaRectangulo(24, 42, 80, 5);
    gotoxy(40, 44);
    printf("Pulsa ENTER para continuar");
    getchar();

    rellenaRectangulo(65, 5, 90, 6);
    rellenaRectangulo(65, 10, 90, 6);
    rellenaRectangulo(65, 10, 90, 32);
    rectangulo(65, 5, 90, 3);
    rectangulo(65, 10, 90, 3);
    rectangulo(65, 15, 90, 25);
    gotoxy(100,7);
    printf("Nuevo jugador");
    gotoxy(67,13);
    printf("N");
    gotoxy(71,13);
    printf("ID");
    gotoxy(78,13);
    printf("Pais");
    gotoxy(83,13);
    printf("Fecha.Nac");
    gotoxy(94,13);
    printf("Altura");
    gotoxy(103,13);
    printf("Nombre");

    gotoxy(67,17);
    muestraJugador(1, IdJugador, Pais, Fecha, NumAltura, Nombre);//Llamada para que aparezca por pantalla el uevo jugador
    altaJugadorSYS(IdJugador,Pais,Fecha,NumAltura,Nombre);//Llamada para escribir al nuevo jugador en jugadores.txt
}

void muestraJugador(int pos, char id_jugador[],char pais[], char fnac[], float altura,char nombre[])//Funcion que imprime por pantalla a los jugadores de la lista o al nuevo jugador dado de alta
{
    printf("%d ",pos);
    printf("%s ",id_jugador);
    printf("%s ",pais);
    printf("%s ",fnac);
    printf("%0.2f ",altura);
    printf("%s ",nombre);
}

void listadoJugadores()//Funcion que llama a cargalistajugadoresSYS para luego llamar a muestralistajugadores para que aparezcan los jugadores por pantalla
{
    char DNI[NUM_JUGADOR][10], pais[NUM_JUGADOR][4], fnac[NUM_JUGADOR][11], nombre[NUM_JUGADOR][DIM_NOMBRE_JUGADOR];
    float altura[NUM_JUGADOR];
    int contador = cargaListaJugadoresSYS(DNI,pais,fnac,altura,nombre);
    if(contador == -1)//si se devuelve esto no se ha podido abrir el archivo
        {
            printf("Error en la carga de las lista de los jugadores");
            return;
        }
    else if(contador == 0)//si se devuelve esto no hay jugadores en el archivo
        {
            printf("No hay jugadores en el archivo jugadores.txt");
            return;
        }
    else
        {
            muestraListaJugadores(contador,DNI,pais,fnac,altura,nombre);
        }
}

void bajaJugadorIU()//Funcion para dar de baja a un jugador y borrarlo de lis lista de jugadores.txt
{
    int opcion, contador;
    char DNI[NUM_JUGADOR][10], pais[NUM_JUGADOR][4], fnac[NUM_JUGADOR][11], nombre[NUM_JUGADOR][DIM_NOMBRE_JUGADOR];
    char vacio[]="vacio";
    float altura[NUM_JUGADOR];
    contador = cargaListaJugadoresSYS(DNI,pais,fnac,altura,nombre);
    muestraListaJugadores(contador,DNI,pais,fnac,altura,nombre);
    rellenaRectangulo(24, 42, 80, 5);
    gotoxy(40, 44);
    printf("Elige un jugador por su numero de orden: ");
    scanf("%d",&opcion);
    strcpy(DNI[opcion-1],vacio);//con esta funcion copiamos la cadena vacio en el DNI del jugador que vamos a borrar
    guardaListaJugadoresSYS(contador,DNI,pais,fnac,altura,nombre);
}
void muestraListaJugadores(int numJugadores, char id_jugador[][10],char pais[][4], char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR])//Funcion que crea una nueva grafica y luego llama a la funcion muestrajugadores para imprimirlos por pantalla
{
    int pos = 1, x = 1;
    int i;
    int columna=66, fila=16;

    rellenaRectangulo(65, 5, 90, 6);
    rellenaRectangulo(65, 10, 90, 6);
    rellenaRectangulo(65, 10, 90, 32);
    rectangulo(65, 5, 90, 3);
    rectangulo(65, 10, 90, 3);
    rectangulo(65, 15, 90, 25);
    gotoxy(100,7);
    printf("LISTADO DE JUGADORES");
    gotoxy(67,13);
    printf("N");
    gotoxy(69,13);
    printf("ID");
    gotoxy(77,13);
    printf("Pais");
    gotoxy(82,13);
    printf("Fecha Nac");
    gotoxy(92,13);
    printf("Altura");
    gotoxy(99,13);
    printf("Nombre");

    for(i=0;i<numJugadores;i++)//Bucle para que aparezcan unos pocos jugadores ya que todos no caben.
    {
        rellenaRectangulo(24, 42, 80, 5);
        gotoxy(40, 44);
        printf("Pulsa ENTER para continuar");
        if(x<=25)//separamos el bucle en dos ya que todos no caben y solo nos caben 25 luego pedimos que se introduzca la tecla ENTER para ver los restantes
        {
            gotoxy(columna,fila);
            muestraJugador(pos,id_jugador[i],pais[i],fnac[i],altura[i],nombre_jugador[i]);
            pos++;
            fila++;
            x++;
        }
        else
        {
            fflush(stdin);
            getchar();
            rellenaRectangulo(65, 15, 90, 27);
            fila=16;
            x=1;
            gotoxy(columna,fila);
            muestraJugador(pos,id_jugador[i],pais[i],fnac[i],altura[i],nombre_jugador[i]);
            fila++;
            pos++;
        }
    }

    rellenaRectangulo(24, 42, 80, 5);
    rellenaRectangulo(24, 47, 80, 5);
    gotoxy(40, 49);
    printf("Introduzca otra opcion para continuar");
    return;
}

