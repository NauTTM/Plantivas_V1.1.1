void inicInterfazUsuario();
int menuPrincipal();
void gestionMenuPrincipal();
