void gestionMenuPlantillas();
int menuPlantillas();
void altaJugadorPlantillaIU();
void muestraJugadorPlantilla(int pos, int id_equipo, char id_jugador[]);
void bajaJugadorPlantillaIU();
void listadoJugadoresPlantilla();
void muestraListaJugadoresPlantilla (int numJugadores, int id_equipo[], char id_jugador[][10]);
