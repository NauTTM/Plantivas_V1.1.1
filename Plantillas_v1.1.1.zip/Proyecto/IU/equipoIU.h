#define DIM_NOMBRE_EQUIPO 50
void altaEquipoIU();
void gestionMenuEquipos();
int menuEquipos();
void listadoEquipos();
void bajaEquipoIU();
void muestraListaEquipos(int numEquipos, int id_equipo[],char nombre_equipo[][DIM_NOMBRE_EQUIPO],char Ciudad[][DIM_NOMBRE_EQUIPO]);
void muestraEquipo(int orden, int id_equipo, char nombre[], char Ciudad[]);
