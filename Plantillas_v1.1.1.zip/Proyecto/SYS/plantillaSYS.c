#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include<stdbool.h>
#include "../AD/plantillaAD.h"
#include "../IU/PlantillasIU.h"
#include "plantillaSYS.h"

bool altaJugadorPlantillaSys(int id_equipo, char id_jugador[])//Funcion que llama a alatajugadorplantillaAD para saber si se ha abierto y escrito correctamente la nueva plantilla
{
    if(altaJugadorPlantillaAD(id_equipo,id_jugador) == -1)//Si devuelve esto no se ha podido abrir el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("La plantilla %d se ha registrado correctamente", id_equipo);
        return true ;
    }
}
int cargaListaJugadoresPlantillaSYS (int id_equipo[],char id_jugador[][10])
{
    int contador = cargaListaJugadoresPlantillaAD(id_equipo,id_jugador);
    if(contador == -1)//si se devuleve este valor no se ha abierto bien el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 44);
        return contador;
    }
}
void eliminaJugadoresEquipo(int y)
{
    int contador;           /*Se declaran las variables con sus vectores y la opcion del equipo de la plantillaque se quiere borrar
                              se le da ese valor - 1 debido a que las cadenas empiezan a contar desde el 0*/
    char id_jugador[50][10];
    int id_equipo[50];
    contador = cargaListaJugadoresPlantillaSYS(id_equipo,id_jugador);
    int i;
    for(i=0;i<contador;i++)//con estos dos bucles hacemos que solo se escriban las plantillas que no hemos borrado
    {
        if(id_equipo[i] == y)
        {
            id_equipo[i] = 0;
        }
    }
    guardaListaJugadoresPlantillaAD(contador,id_equipo,id_jugador);
}
