#include<stdbool.h>
bool altaJugadorPlantillaSys(int id_equipo, char id_jugador[]);
int cargaListaJugadoresPlantillaSYS (int id_equipo[],char id_jugador[][10]);void eliminaJugadoresEquipo (int id_equipo);
