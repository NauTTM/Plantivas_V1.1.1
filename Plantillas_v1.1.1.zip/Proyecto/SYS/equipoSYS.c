#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include<stdbool.h>
#include "../AD/equipoAD.h"
#include "equipoSYS.h"
#define NUM_EQUIPOS 100
#define DIM_NOMBRE_EQUIPO 50

bool altaEquipoSYS(int IdEquipo, char Nombre[], char Ciudad[])//Funcion que llama a la funcion alaequipoAD para saber si el archivo se ha abierto correctamente
{

    if(altaEquipoAD(IdEquipo, Nombre,Ciudad)==-1)//si devuelve esto no se ha podido abrir el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");//si se devuleve este valor no se ha abierto bien el archivo
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("El equipo %s se ha registrado correctamente", Nombre);
        return true ;
    }
}
int cargaListaEquiposSYS(int id_equipo[], char nombre[][DIM_NOMBRE_EQUIPO], char Ciudad[][DIM_NOMBRE_EQUIPO])//Funci�n que llama a cargalistaequiposAD para saber si todo ha ido bien y devuelve el numero de equipos
{
    int contador = cargaListaEquiposAD(id_equipo,nombre,Ciudad);
    if(contador == -1)//si se devuleve este valor no se ha abierto bien el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 44);
        return contador;
    }
}
bool guardaListaEquiposSYS(int numEquipos, int id_equipo[],char nombre_equipo[][DIM_NOMBRE_EQUIPO],char Ciudad[][DIM_NOMBRE_EQUIPO])//Funcion que llama a guardalistaequiposAD para saber si todo ha salido correctamente
{
    if(guardaListaEquiposAD(numEquipos,id_equipo,nombre_equipo,Ciudad)==-1)//si se devuleve este valor no se ha abierto bien el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Algo ha salido mal");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Todo ha ido bien");
        return true ;
    }
}
