#include<stdio.h>
#include "interfazUsuario.h"
#include "InterfazGrafica.h"
#include<stdbool.h>
#include "../AD/JugadorAD.h"
#include "JugadorSYS.h"

bool altaJugadorSYS(char id_jugador[], char pais[], char fnac[], float altura, char nombre[])//Funcion que llama a alatajugador AD para saber si todo ha funcionado bien
{

    if(altaJugadorAD(id_jugador,pais,fnac,altura,nombre) == -1)//si se devuelve esto no se ha podido abrir el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("El jugador %s se ha registrado correctamente", nombre);
        return true ;
    }
}

int cargaListaJugadoresSYS(char id_jugador[][10], char pais[][4],char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR])//Funcion que llama a cargalistajugadores AD para saber si se han cargado bien y devuelve el numero de jugadores
{
    int contador = cargaListaJugadoresAD(id_jugador,pais,fnac,altura,nombre_jugador);
    if(contador == -1)//si se devuelve esto no se ha podido abrir el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else//se devuelve el numero de jugadores
    {

        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        return contador;
    }
}
bool guardaListaJugadoresSYS(int numJugadores, char id_jugador[][10],char pais[][4], char fnac[][11], float altura[],char nombre_jugador[][DIM_NOMBRE_JUGADOR])//Funcion que llama a cargalistajugadoresAD para saber si se han escrito todos los jugadores menos el que hemos borrado
{
    if(guardaListaJugadoresAD(numJugadores,id_jugador,pais,fnac,altura,nombre_jugador) == -1)//si se devuelve esto no se ha podido abrir el archivo
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Error al abrir el programa");
        return false;
    }
    else
    {
        rellenaRectangulo(24, 42, 80, 5);
        rellenaRectangulo(24, 47, 80, 5);
        gotoxy(40, 49);
        printf("Todo ha ido bien");
        return true ;
    }

}
