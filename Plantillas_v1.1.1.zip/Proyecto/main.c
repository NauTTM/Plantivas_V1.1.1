#include <stdio.h>
#include "IU\interfazGrafica.h"
#include<conio.h>


int main()
{
    system("Proyecto");

    rectangulo(0, 0, 100, 3);
    rectangulo(0, 5, 60, 3);
    rectangulo(0, 10, 60, 30);
    rectangulo(0, 42, 20, 3);
    rectangulo(24, 42, 80, 3);
    rectangulo(0, 47, 20, 3);
    rectangulo(24, 47, 80, 3);

    gotoxy(40, 2);
    printf("GESTOR DE PLANTILLAS");
    gotoxy(20, 6);
    printf("Gestion de jugadores");
    gotoxy(2, 44);
    printf("ENTRADA DE DATOS");
    gotoxy(6, 49);
    printf("MENSAJES");


    gotoxy(40, 44);
    int NumDorsal;
    printf("Introduzca dorsal del jugador 1:");
    scanf("%d",&NumDorsal);
    gotoxy(2, 11);
    printf("Dorsal: %d",NumDorsal);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    float NumAltura;
    printf("Introduzca altura del jugador 1:");
    scanf("%f",&NumAltura);
    gotoxy(2, 13);
    printf("Altura: %.2f",NumAltura);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    int NumDia;
    printf("Introduzca dia de nacimiento jugador 1:");
    scanf("%d",&NumDia);
    gotoxy(2, 15);
    printf("Dia: %d",NumDia);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(40, 44);
    int NumMes;
    printf("Introduzca mes de nacimiento jugador 1:");
    scanf("%d",&NumMes);
    gotoxy(2, 17);
    printf("Mes: %d",NumMes);
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(25, 44);
    int NumAno;
    printf("Introduzca Ano de nacimiento jugador 1:");
    scanf("%d",&NumAno);
    gotoxy(2, 19);
    printf("Ano: %d",NumAno);
    rellenaRectangulo(24, 42, 80, 5);

    rellenaRectangulo(0, 10, 60, 30);
    gotoxy(40,49);

    printf("Datos del Jugador 1 guardados");
    rellenaRectangulo(24, 42, 80, 5);

    gotoxy(1,8);
    printf("Dorsal");
    gotoxy(7,8);
    printf("/Altura");
    gotoxy(14,8);
    printf("/Fecha de nacimiento");

    int Datos1;
    float Datos2;
    int Datos3;
    int Datos4;
    int Datos5;
    FILE *jugadores;
    jugadores=fopen("jugadores.txt","rt");
    fscanf(jugadores,"%d %f %d %d %d",&Datos1, &Datos2, &Datos3, &Datos4, &Datos5);
    gotoxy(2, 12);
    printf("%d %.2f %d %d %d",Datos1, Datos2, Datos3, Datos4, Datos5);

    int Datos6;
    float Datos7;
    int Datos8;
    int Datos9;
    int Datos10;
    fscanf(jugadores,"%d %f %d %d %d",&Datos6, &Datos7, &Datos8, &Datos9, &Datos10);
    gotoxy(2, 14);
    printf("%d %.2f %d %d %d",Datos6, Datos7, Datos8, Datos9, Datos10);

    int Datos11;
    float Datos12;
    int Datos13;
    int Datos14;
    int Datos15;
    fscanf(jugadores,"%d %f %d %d %d",&Datos11, &Datos12, &Datos13, &Datos14, &Datos15);
    gotoxy(2, 16);
    printf("%d %.2f %d %d %d",Datos11, Datos12, Datos13, Datos14, Datos15);

    fclose(jugadores);

    gotoxy(40,49);
    printf("Datos de los 3 jugadores guardados");
    rellenaRectangulo(24, 42, 80, 5);

    getch();
    return 0;
}
